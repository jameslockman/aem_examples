// The curly brace below balances the brace from the try in the INIT script
}
catch (err) {
    throw 'An error occurred during media extraction: ' + (err.message ? err.message : err);
}
finally {
     //==== remove the original resource file ====
    app.consoleout('Finished EPS Thumbnail export...');

	cleanup(exportFolderThumbnail);
	sourceFile.remove();
    cleanup(sourceFolder);
    cleanup(exportFolder);
}