app.consoleout('initiating process');

if (app.scriptArgs.isDefined("credentials")) {
    var credentials = app.scriptArgs.getValue("credentials");
} else {
    throw "CQ host credentials argument is missing";
}
if (app.scriptArgs.isDefined("cqHost")) {
    var host = app.scriptArgs.getValue("cqHost");
} else {
    throw "cqHost argument is missing";
}
if (app.scriptArgs.isDefined("resource")) {
    var resourcePath = app.scriptArgs.getValue("resource");
} else {
    throw "resource argument is missing";
}
if (app.scriptArgs.isDefined("idsCCServer")) {
    var idsCCServer = app.scriptArgs.getValue("idsCCServer");
} else {
    throw "idsCCServer argument is missing";
}

if (app.scriptArgs.isDefined("proxyJobId")){
    var proxyJobId = app.scriptArgs.getValue("proxyJobId");
}
else {
    throw "proxyJobId argument is missing";
}

try {
    app.consoleout('setting up variables');
    var exportFolder = new Folder("tmp-" + proxyJobId);
    exportFolder.create();
    var sourceFolder = new Folder("tmpsrc-" + proxyJobId);
    sourceFolder.create();
    fileName = resourcePath.substring (resourcePath.lastIndexOf ('/'));

    var sourceFile = new File(sourceFolder.fullName + fileName);

    app.consoleout('Fetching resource from CQ: ' + host + resourcePath + ' to ' + sourceFile);
    fetchResource (host,  credentials, resourcePath, sourceFile);

    var target = resourcePath.substring (0, resourcePath.lastIndexOf ('/')) + "/renditions";