//Thumbnail generator for AEM Assets
//This script creates a new 319x319 document, imports the payload onto the page, and centers 
//and scales the payload to fit the page.
//It next exports the image as a series of thumbnail renditions.
//Lastly, it posts the renditions back to AEM as renditions of the payload.

//==============================================================================
// Export the pages of any Indesign document as Thumbnails
//==============================================================================

app.consoleout('Started EPS Thumbnail export...');
var exportFolderThumbnail = new Folder(exportFolder.fullName + "/thumbnail");
exportFolderThumbnail.create();

try {
    exportThumbnail(document, exportFolderThumbnail.fullName, fileName, resourcePath, host, credentials);
    }
catch (err) {
    throw 'Unable to save EPS Thumbnails for ' + sourceFile + ': ' + err.message;
    }


//This is the function that does all of the work.
//See the comments to learn about each set of configuration options
function exportThumbnail(document, folderName, fileName, resourcePath, host, credentials) {
	var myDocument = app.documents.add();
    //set the margins to 0
    myDocument.marginPreferences.top = 0;
    myDocument.marginPreferences.left = 0;
    myDocument.marginPreferences.bottom = 0;
    myDocument.marginPreferences.right = 0;
    //The following assumes that your default master spread contains two facing pages.
    //We set the margins on the master spread to 0 as well, on the left and right pages
    myDocument.masterSpreads.item(0).pages.item(0).marginPreferences.top = 0;
    myDocument.masterSpreads.item(0).pages.item(0).marginPreferences.left = 0;
    myDocument.masterSpreads.item(0).pages.item(0).marginPreferences.bottom = 0;
    myDocument.masterSpreads.item(0).pages.item(0).marginPreferences.right = 0;
    myDocument.masterSpreads.item(0).pages.item(1).marginPreferences.top = 0;
    myDocument.masterSpreads.item(0).pages.item(1).marginPreferences.left = 0;
    myDocument.masterSpreads.item(0).pages.item(1).marginPreferences.bottom = 0;
    myDocument.masterSpreads.item(0).pages.item(1).marginPreferences.right = 0;
    //We set the page width and height to 319px, with portrait orientation
    myDocument.documentPreferences.pageHeight = "319px";
    myDocument.documentPreferences.pageWidth = "319px";
    myDocument.documentPreferences.pageOrientation = PageOrientation.portrait;
    //One page only
    myDocument.documentPreferences.pagesPerDocument = 1;

    //These settings control how InDesign Server handles black ink.
    //False means that InDesign will attempt to display how the black ink 
    //will interact with the substrate and the other inks in the job.
    //True will use a faster but less accurate model. The faster, less accurate model 
    //is the default behavior in InDesign, which is why we need to change the setting here.
    app.colorSettings.idealizedBlackToExport = false;
    app.colorSettings.idealizedBlackToScreen = false;


    //PNG export options here. 
    //Disable anti-alias to hide boundaries between atomic regions created by transparency flattening
    app.pngExportPreferences.antiAlias = false;
    //All pages must be exported for PNG. We only have 1 page, but we need to specify the range
    app.pngExportPreferences.pngExportRange = PNGExportRangeEnum.EXPORT_ALL;
    //We want to simutate overprinting. This works in conjunction with the black setting above.
    app.pngExportPreferences.simulateOverprint = true;
    //We want the color space to be RGB.
    app.pngExportPreferences.pngColorSpace = PNGColorSpaceEnum.RGB;
    //We want a high quality PNG
    app.pngExportPreferences.pngQuality = PNGQualityEnum.HIGH;
    //Resolution set to 72 to generate 319 x 319 preview. We will adjust for each preview size.
    app.pngExportPreferences.exportResolution = 72;
	//Enable PNG transparency
    app.pngExportPreferences.transparentBackground = true;
    //JPEG export options here. The same settings apply for JPEG as for PNG
    app.jpegExportPreferences.antiAlias = false;
    app.jpegExportPreferences.simulateOverprint = true;
    app.jpegExportPreferences.jpegQuality = JPEGOptionsQuality.MAXIMUM;
    //Resolution set to 300 for high quality JPEG for zooming.
    app.jpegExportPreferences.exportResolution = 300;

	//Prepare for the thumbnail files
    var jpegRendition=new File(exportFolderThumbnail+"/"+"cq5dam.rendition.jpg");
    var thumbnail319=new File(exportFolderThumbnail+"/"+"cq5dam.thumbnail.319.319.png");
    var thumbnail140=new File(exportFolderThumbnail+"/"+"cq5dam.thumbnail.140.140.png");
    var thumbnail48=new File(exportFolderThumbnail+"/"+"cq5dam.thumbnail.48.48.png");
    var thumbnail1280=new File(exportFolderThumbnail+"/"+"cq5dam.web.1280.1280.png");

    //Create a new page in the document
    var myPage = myDocument.pages.item(0);
    //Get the page size as an array
    var myBounds = myGetBounds(myDocument, myPage);

    //Transparency background support
	var color = makeColor(myDocument, "Transparency Color", ColorSpace.RGB, ColorModel.process, [200,200,200]);

    //Create a new text frame
    var myImageFrame = myDocument.pages.item(0).rectangles.add();
	//Make the image frame fill the page
    myImageFrame.geometricBounds = myBounds;


    //Ensure that the placed file will center in the frame and fit proportiionally
    myDocument.frameFittingOptions.properties.fittingAlignment=AnchorPoint.TOP_LEFT_ANCHOR;
    myDocument.frameFittingOptions.properties.fittingOnEmptyFrame=EmptyFrameFittingOptions.FILL_PROPORTIONALLY;
    myImageFrame.frameFittingOptions.properties.fittingAlignment=AnchorPoint.TOP_LEFT_ANCHOR;
    myImageFrame.frameFittingOptions.properties.fittingOnEmptyFrame=EmptyFrameFittingOptions.FILL_PROPORTIONALLY;

    //Remove the black stroke on the frame
    myImageFrame.strokeWeight = 0;

    //Add gray background to support transparency
    //myImageFrame.fillColor = color;

    //Set the PDF Import Options
    app.pdfPlacePreferences.pdfCrop = PDFCrop.cropMedia;

    //Place the payload into the frame
    myImageFrame.place(sourceFile);

    //Fit the payload in the frame proportionally and centered
    myImageFrame.fit(FitOptions.PROPORTIONALLY);

    //Export the JPEG Rendition
    myImageFrame.exportFile(ExportFormat.JPG, jpegRendition);

    //Export the 319 thumbnail
    myImageFrame.exportFile(ExportFormat.PNG_FORMAT, thumbnail319);

    //adjust the resolution and export the 140 thumbnail
    app.pngExportPreferences.exportResolution = 32;
    myImageFrame.exportFile(ExportFormat.PNG_FORMAT, thumbnail140);

    //adjust the resolution and export the 48 thumbnail
    app.pngExportPreferences.exportResolution = 11;
    myImageFrame.exportFile(ExportFormat.PNG_FORMAT, thumbnail48);

    //adjust the resolution and export the 1280 thumbnail
    app.pngExportPreferences.exportResolution = 289;
    myImageFrame.exportFile(ExportFormat.PNG_FORMAT, thumbnail1280);


    //Close the temporary document without saving
    myDocument.close(SaveOptions.NO);

    //==== send files to AEM ====
    app.consoleout('Posting this file to AEM: ' + "cq5dam.rendition.jpg");
    app.consoleout('Posting to location: ' + target);
    putResource (host, credentials, jpegRendition, "cq5dam.rendition.jpg", 'image/jpeg', target);

    app.consoleout('Posting this file to AEM: ' + "cq5dam.thumbnail.140.140.png");
    app.consoleout('Posting to location: ' + target);
    putResource (host, credentials, thumbnail140, "cq5dam.thumbnail.140.140.png", 'image/png', target);

    app.consoleout('Posting this file to AEM: ' + "cq5dam.thumbnail.48.48.png");
    app.consoleout('Posting to location: ' + target);
    putResource (host, credentials, thumbnail48, "cq5dam.thumbnail.48.48.png", 'image/png', target);

    app.consoleout('Posting this file to AEM: ' + "cq5dam.web.1280.1280.png");
    app.consoleout('Posting to location: ' + target);
    putResource (host, credentials, thumbnail1280, "cq5dam.web.1280.1280.png", 'image/png', target);

    app.consoleout('Posting this file to AEM: ' + "cq5dam.thumbnail.319.319.png");
    app.consoleout('Posting to location: ' + target);
    putResource (host, credentials, thumbnail319, "cq5dam.thumbnail.319.319.png", 'image/png', target);

}

//myGetBounds is a function that returns the bounds
//of the "live area" of the page
function myGetBounds(myDocument, myPage) {
    var myPageWidth = myDocument.documentPreferences.pageWidth;
    var myPageHeight = myDocument.documentPreferences.pageHeight;
    var myX1,myX2,myY1,myY2 = 0;
    if (myPage.side === PageSideOptions.leftHand) {
        myX2 = myPage.marginPreferences.left;
        myX1 = myPage.marginPreferences.right;
    } else {
        myX1 = myPage.marginPreferences.right;
        myX2 = myPage.marginPreferences.left;
    }
    myY1 = myPage.marginPreferences.top;
    myX2 = myPageWidth - myX2;
    myY2 = myPageHeight - myPage.marginPreferences.bottom;
    return [myY1, myX1, myY2, myX2];
}

//makeColor is a function that creates a new color
function makeColor(doc, colorName, colorSpace, colorModel, colorValue) {  
    var color = doc.colors.item(colorName);
    if (!color.isValid) {  
        color = doc.colors.add({name: colorName, space: colorSpace, model: colorModel, colorValue: colorValue});  
    }  
    return color;  
}
