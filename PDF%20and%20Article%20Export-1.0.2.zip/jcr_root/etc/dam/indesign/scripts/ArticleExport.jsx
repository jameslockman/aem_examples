//==============================================================================
// Export any Indesign document as .artile
// This script requires that the InDesign file have an alternate layout with
// the name "iPad H". You can change or eliminate this requirement, but the
// result may not be what you expect if you do not specify a specific alternate
// layout.
//==============================================================================

//==== get soap arguments ====
if (app.scriptArgs.isDefined("credentials")) {
	var credentials = app.scriptArgs.getValue("credentials");
} else {
	throw "CQ host credentials argument is missing";
}
if (app.scriptArgs.isDefined("cqHost")) {
	var host = app.scriptArgs.getValue("cqHost");
} else {
	throw "cqHost argument is missing";
}
if (app.scriptArgs.isDefined("resource")) {
	var resourcePath = app.scriptArgs.getValue("resource");
} else {
	throw "resource argument is missing";
}

//==== create a temporary folder under InDesign server tmp directory to fetch and export ====
// added randomness to the folder name
var exportFolder = new Folder("tmp-" + (new Date().getTime() - Math.floor((Math.random() * 10000) + 1)));
exportFolder.create();

fileName = resourcePath.substring(resourcePath.lastIndexOf('/'), resourcePath.lastIndexOf('.'));
var sourceFile = new File(exportFolder.fullName + fileName + '.indd');
var outputFile = new File(exportFolder.fullName + fileName + '.article');

app.consoleout('Starting Article Export: Fetching resource from CQ: ' + resourcePath);
fetchResource(host, credentials, resourcePath, sourceFile);

var document = app.open(sourceFile);
var articleLayout = "iPad H";  //change this to your desired layout name
var articleSettings = [
	["assetformat", "pdf"], // pdf, png, jpg or auto (auto chooses between png and jpg)
	["width", 1024], // the width dimension of the target
	["height", 768], // the height dimension of the target
	["layout", articleLayout], // layout name (if not supplied, all pages are exported)
	["showprogressbar", false] // give the user some feedback
];

var section = document.sections.count();
var alternateLayouts = [];

try {
	for (i = 0; i < section; i++) {
		if (document.sections.item(i).alternateLayout == articleLayout) {
			//==== output the article ====
            var output = app.exportDpsArticle(outputFile, document, articleSettings);
			if (output && output.length > 0) {
				app.consoleout("Output: " + output);
			}
			//==== send file to CQ ====
			var target = resourcePath.substring(0, resourcePath.lastIndexOf('/')) + "/renditions";
			//==== send the export back to CQ ====
			app.consoleout('Posting this file to CQ: ' + exportFolder.fullName + fileName + '.article');
			app.consoleout('Posting to location: ' + target);
			putResource(host, credentials, outputFile, fileName + '.article', 'application/article', target);
			returnValue = "DPS article exported and posted successfully";
			break;
		}
	}

	//==== remove the original resources ====
	// close the document
	document.close(SaveOptions.no);

	//Remove the source document
	sourceFile.remove();


} finally {
	//==== remove the temp folder ====
	cleanup(exportFolder);

}
app.consoleout('Finished DPS article export');
