//==============================================================================
// Export any Indesign document as PDF
//==============================================================================

//==== get soap arguments ====
if (app.scriptArgs.isDefined("credentials")) {
    var credentials = app.scriptArgs.getValue("credentials");
} else {
    throw "CQ host credentials argument is missing";
}
if (app.scriptArgs.isDefined("cqHost")) { 
    var host = app.scriptArgs.getValue("cqHost");
} else {
    throw "cqHost argument is missing";
}
if (app.scriptArgs.isDefined("resource")) { 
    var resourcePath = app.scriptArgs.getValue("resource");
} else {
    throw "resource argument is missing";
}


try {
    //==== create a temporary folder under InDesign server tmp directory to fetch and export ====
    // added randomness to the folder name
    var exportFolder = new Folder("tmp-" + (new Date().getTime() - Math.floor((Math.random()*10000)+1) ));
    exportFolder.create();
    fileName = resourcePath.substring (resourcePath.lastIndexOf ('/'), resourcePath.lastIndexOf ('.'));
    var sourceFile = new File(exportFolder.fullName + fileName + '.indd');
    var outputFile = new File(exportFolder.fullName + fileName + '.pdf');

    app.consoleout('Fetching resource from CQ: '+resourcePath);
    fetchResource (host,  credentials, resourcePath, sourceFile);

    app.consoleout('open' + exportFolder.fullName + fileName + '.indd');
    var document = app.open(sourceFile);
	var pdfExportPreset = "[Print Preset]"  // Set your PDF Print-ready Export Preset (joboption) here.
    										// You can use any joboption file installed in InDesign Server

    with (app.pdfExportPreferences) {
        viewDocumentAfterExport = false;
    }
    var myPDFExportPreset = app.pdfExportPresets.item(pdfExportPreset);
    document.exportFile(ExportFormat.pdfType, outputFile,myPDFExportPreset);

    // close the document
    document.close(SaveOptions.no);
    
    //==== remove the original resource and send the export back to CQ ====
    sourceFile.remove();

    //==== send file to CQ ====
    var target = resourcePath.substring (0, resourcePath.lastIndexOf ('/')) + "/renditions";
    app.consoleout('Posting this file to CQ: '+exportFolder.fullName + fileName + '.pdf');
    app.consoleout('Posting to location: ' + target);
    putResource (host, credentials,  outputFile, fileName+'_print.pdf', 'application/pdf', target);
    returnValue = "PDF for Print exported and posted successfully";
} finally {
    //==== remove the temp folder ====
    cleanup(exportFolder);
}
app.consoleout('Finished PDF for Print export using '+pdfExportPreset+' joboptions');